package com.ardillita.world;

import com.ardillita.registry.ModEntities;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class SpawnHandler {
    @SubscribeEvent
    public static void onBiomeLoading(BiomeLoadingEvent event) {
        event.getSpawns().getSpawner(MobCategory.CREATURE).add(new MobCategory.SpawnerData(ModEntities.ARDILLITA.get(), 18, 2, 4));
    }
}
