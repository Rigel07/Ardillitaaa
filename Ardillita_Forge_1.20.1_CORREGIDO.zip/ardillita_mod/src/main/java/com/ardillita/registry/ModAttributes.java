package com.ardillita.registry;

import com.ardillita.ArdillitaMod;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ArdillitaMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModAttributes {
    @SubscribeEvent
    public static void register(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ARDILLITA.get(), com.ardillita.entity.ArdillitaEntity.createAttributes().build());
    }
    private ModAttributes() {}
}
