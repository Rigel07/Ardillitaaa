package com.ardillita.registry;

import com.ardillita.ArdillitaMod;
import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ArdillitaMod.MOD_ID);
    public static final RegistryObject<EntityType<ArdillitaEntity>> ARDILLITA = ENTITIES.register("ardillita", () ->
            EntityType.Builder.of(ArdillitaEntity::new, MobCategory.CREATURE)
                    .sized(0.55F, 0.55F)
                    .clientTrackingRange(8)
                    .build(ArdillitaMod.MOD_ID + ":ardillita"));
    private ModEntities() {}
}
