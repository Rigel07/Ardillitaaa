package com.ardillita.registry;

import com.ardillita.ArdillitaMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ArdillitaMod.MOD_ID);
    public static final RegistryObject<Block> ARDILLITA_NEST = BLOCKS.register("ardillita_nest",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(0.4F).noOcclusion()));
    private ModBlocks() {}
}
