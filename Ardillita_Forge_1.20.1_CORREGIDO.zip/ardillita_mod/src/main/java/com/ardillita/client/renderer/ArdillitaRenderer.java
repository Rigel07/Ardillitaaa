package com.ardillita.client.renderer;

import com.ardillita.ArdillitaMod;
import com.ardillita.client.ClientSetup;
import com.ardillita.client.model.ArdillitaModel;
import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ArdillitaRenderer extends MobRenderer<ArdillitaEntity, ArdillitaModel<ArdillitaEntity>> {
    private static final ResourceLocation NORMAL = new ResourceLocation(ArdillitaMod.MOD_ID, "textures/entity/ardillita.png");
    private static final ResourceLocation PINK = new ResourceLocation(ArdillitaMod.MOD_ID, "textures/entity/ardillita_pink.png");

    public ArdillitaRenderer(EntityRendererProvider.Context context) {
        super(context, new ArdillitaModel<>(context.bakeLayer(ClientSetup.ARDILLITA_LAYER)), 0.25F);
    }

    @Override
    public ResourceLocation getTextureLocation(ArdillitaEntity entity) {
        return entity.isPink() ? PINK : NORMAL;
    }
}
