package com.ardillita;

import com.ardillita.registry.ModBlocks;
import com.ardillita.registry.ModEntities;
import com.ardillita.registry.ModItems;
import com.ardillita.registry.ModSounds;
import com.ardillita.world.SpawnHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ArdillitaMod.MOD_ID)
public class ArdillitaMod {
    public static final String MOD_ID = "ardillita";

    public ArdillitaMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        MinecraftForge.EVENT_BUS.register(SpawnHandler.class);
    }
}
