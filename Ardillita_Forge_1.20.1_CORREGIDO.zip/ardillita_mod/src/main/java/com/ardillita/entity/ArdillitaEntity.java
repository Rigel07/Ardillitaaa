package com.ardillita.entity;

import com.ardillita.registry.ModBlocks;
import com.ardillita.registry.ModItems;
import com.ardillita.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.TamableAnimal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.recipe.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ArdillitaEntity extends TamableAnimal {
    private static final String PINK_TAG = "Pink";
    private static final String FETCH_TAG = "FetchMode";
    private boolean pink;
    private boolean fetchMode;
    private int fetchCooldown;

    public ArdillitaEntity(EntityType<? extends TamableAnimal> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.0F);
        this.setCanPickUpLoot(false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new PanicGoal(this, 1.25D));
        this.goalSelector.addGoal(3, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.15D, 3.0F, 12.0F, false));
        this.goalSelector.addGoal(5, new TemptGoal(this, 1.1D, Ingredient.of(ModItems.BELLOTA.get()), false));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        if (this.fetchCooldown > 0) this.fetchCooldown--;
        if (this.fetchMode && this.isTame() && !this.isOrderedToSit() && this.fetchCooldown == 0) {
            fetchNearestItem();
            this.fetchCooldown = 60;
        }

        if (this.tickCount % 800 == 0 && this.random.nextFloat() < 0.25F) {
            tryMakeNest();
        }
    }

    private void fetchNearestItem() {
        Player owner = this.getOwner() instanceof Player p ? p : null;
        if (owner == null || this.distanceToSqr(owner) > 256.0D) return;
        AABB box = this.getBoundingBox().inflate(10.0D);
        List<ItemEntity> items = this.level().getEntitiesOfClass(ItemEntity.class, box, e -> !e.getItem().isEmpty());
        if (items.isEmpty()) return;
        ItemEntity target = items.get(0);
        double best = this.distanceToSqr(target);
        for (ItemEntity item : items) {
            double d = this.distanceToSqr(item);
            if (d < best) { best = d; target = item; }
        }
        if (this.distanceToSqr(target) < 3.0D) {
            ItemStack stack = target.getItem().copy();
            target.discard();
            if (!owner.getInventory().add(stack)) owner.drop(stack, false);
            this.playSound(ModSounds.ARDILLITA_HAPPY.get(), 0.8F, 1.15F);
            this.level().broadcastEntityEvent(this, (byte) 7);
        } else {
            this.getNavigation().moveTo(target, 1.25D);
        }
    }

    private void tryMakeNest() {
        BlockPos origin = this.blockPosition().above();
        for (int i = 0; i < 8; i++) {
            BlockPos p = origin.offset(this.random.nextInt(5) - 2, this.random.nextInt(5) - 2, this.random.nextInt(5) - 2);
            if (this.level().getBlockState(p).is(BlockTags.LEAVES) && this.level().isEmptyBlock(p.below())) {
                this.level().setBlock(p.below(), ModBlocks.ARDILLITA_NEST.get().defaultBlockState(), 3);
                this.playSound(ModSounds.ARDILLITA_HAPPY.get(), 0.45F, 1.0F);
                break;
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!this.isTame() && stack.is(ModItems.BELLOTA.get())) {
            if (!player.getAbilities().instabuild) stack.shrink(1);
            if (!this.level().isClientSide) {
                {
                    this.tame(player);
                    this.setOrderedToSit(false);
                    this.playSound(ModSounds.ARDILLITA_HAPPY.get(), 1.0F, 1.1F);
                    this.level().broadcastEntityEvent(this, (byte) 7);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        if (this.isTame() && player.equals(this.getOwner())) {
            if (stack.isEmpty()) {
                if (!this.level().isClientSide) {
                    if (this.isOrderedToSit()) {
                        this.setOrderedToSit(false);
                        this.fetchMode = false;
                        this.playSound(ModSounds.ARDILLITA_HAPPY.get(), 0.8F, 1.2F);
                    } else if (!this.fetchMode) {
                        this.fetchMode = true;
                        this.playSound(ModSounds.ARDILLITA_HAPPY.get(), 0.8F, 1.05F);
                    } else {
                        this.fetchMode = false;
                        this.setOrderedToSit(true);
                    }
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            if (stack.is(ModItems.BELLOTA.get())) {
                if (!player.getAbilities().instabuild) stack.shrink(1);
                this.heal(2.0F);
                this.playSound(ModSounds.ARDILLITA_EAT.get(), 0.8F, 1.1F);
                this.level().broadcastEntityEvent(this, (byte) 7);
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 7) {
            for (int i = 0; i < 6; i++) {
                this.level().addParticle(ParticleTypes.HEART, this.getRandomX(0.5D), this.getRandomY(), this.getRandomZ(0.5D), 0, 0.04D, 0);
            }
        } else super.handleEntityEvent(id);
    }

    @Override
    public boolean onClimbable() {
        return this.horizontalCollision || this.level().getBlockState(this.blockPosition()).is(BlockTags.LEAVES);
    }

    @Override
    public void travel(net.minecraft.world.phys.Vec3 travelVector) {
        if (this.onClimbable() && this.horizontalCollision) {
            this.setDeltaMovement(this.getDeltaMovement().x * 0.75D, 0.16D, this.getDeltaMovement().z * 0.75D);
            this.hasImpulse = true;
        }
        super.travel(travelVector);
    }

    @Override
    public boolean checkSpawnRules(LevelAccessor level, MobSpawnType reason) {
        if (!Animal.checkAnimalSpawnRules(this.getType(), level, reason, this.blockPosition(), this.random)) return false;
        BlockPos center = this.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-4, -3, -4), center.offset(4, 4, 4))) {
            if (level.getBlockState(p).is(BlockTags.LEAVES)) return true;
        }
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean(PINK_TAG, this.pink);
        tag.putBoolean(FETCH_TAG, this.fetchMode);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.pink = tag.getBoolean(PINK_TAG);
        this.fetchMode = tag.getBoolean(FETCH_TAG);
    }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        ArdillitaEntity child = com.ardillita.registry.ModEntities.ARDILLITA.get().create(level);
        if (child != null) child.pink = this.pink || (otherParent instanceof ArdillitaEntity a && a.pink) || this.random.nextFloat() < 0.02F;
        return child;
    }

    @Override
    public @Nullable net.minecraft.world.entity.SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level, net.minecraft.world.DifficultyInstance difficulty, MobSpawnType reason, @Nullable net.minecraft.world.entity.SpawnGroupData data, @Nullable CompoundTag tag) {
        this.pink = this.random.nextFloat() < 0.025F;
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    public boolean isPink() { return pink; }
    public boolean isFetchMode() { return fetchMode; }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.ARDILLITA_CHIRP.get(); }
    @Override protected SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource source) { return ModSounds.ARDILLITA_CHIRP.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.ARDILLITA_CHIRP.get(); }

    @Override
    public boolean isFood(ItemStack stack) { return stack.is(ModItems.BELLOTA.get()); }

    @Override
    public boolean canMate(Animal otherAnimal) {
        return otherAnimal instanceof ArdillitaEntity other && this.isTame() && other.isTame() && !other.isOrderedToSit() && super.canMate(other);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) { return !this.isTame() && super.removeWhenFarAway(distanceToClosestPlayer); }
}
